#!/bin/bash

sudo apt-get update -y
sudo apt-get install geany -y

sudo apt-get update -y
sudo apt-get install firefox -y

sudo apt-get update -y
sudo apt-get virtualbox -y

sudo apt-get install python-software-properties  -y
sudo add-apt-repository ppa:chris-lea/node.js  -y
sudo apt-get update  -y
sudo apt-get install nodejs -y

sudo apt-get update -y
sudo apt-get install git -y

cd /tmp 
git clone http://github.com/isaacs/npm.git 
cd npm  -y
sudo make install  -y
cd ../..  -y
sudo npm install -g express -y

sudo npm install -g n -y
sudo npm install socket.io -y

sudo echo "deb http://downloads-distro.mongodb.org/repo/ubuntu-upstart dist 10gen" > /etc/apt/sources.list.d/mongo.list
sudo apt-key adv --keyserver keyserver.ubuntu.com --recv 7F0CEB10 -y
sudo apt-get update
sudo apt-get install mongodb-10gen

sudo npm install express
sudo npm install mongoose
sudo npm install connect
sudo npm install bcrypt
sudo npm install session.socket.io

sudo apt-get install wget -y
sudo apt-get update
sudo apt-get install linux-image-extra-`uname -r`
sudo sh -c "wget -qO- https://get.docker.io/gpg | apt-key add -"
sudo sh -c "echo deb http://get.docker.io/ubuntu docker main > /etc/apt/sources.list.d/docker.list"
sudo apt-get update
sudo apt-get install lxc-docker -y


sudo add-apt-repository ppa:gnome3-team/gnome3 -y
sudo apt-get update -y
sudo apt-get install gnome-shell -y
sudo apt-get install ubuntu-desktop -y
sudo apt-get install gdm -y
sudo dpkg-reconfigure gdm -y
